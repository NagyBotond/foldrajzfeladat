﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using MySql.Data.MySqlClient;
using System.IO;
using System.Threading;

namespace NBJ_kekhegy
{
    public partial class Form1 : Form
    {
        public static class Conn
        {

            public static readonly MySqlConnection conn = new MySqlConnection("server=localhost;user=root;port=3306;password=;database=foldrajz");
        }
        public Form1()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            richTextBox1.ReadOnly = true;
            string connStr = "server=localhost;user=root;port=3306;password=";

            MySqlConnection connNoDB = new MySqlConnection(connStr);
            MySqlCommand drdatabase = new MySqlCommand("DROP DATABASE IF EXISTS foldrajz", connNoDB);
            connNoDB.Open();
            drdatabase.ExecuteNonQuery();
            connNoDB.Close();
            MySqlCommand crdatabase = new MySqlCommand("CREATE DATABASE foldrajz DEFAULT CHARSET utf8 COLLATE utf8_hungarian_ci", connNoDB);
            connNoDB.Open();
            crdatabase.ExecuteNonQuery();
            connNoDB.Close();
        }

        private void button3_Click(object sender, EventArgs e)
        {
            try
            {
                Conn.conn.Close();
                richTextBox1.Text += " \n DB kapcsolat bontva";
                button3.Enabled = false;
                button1.Enabled = true;
            }
            catch (Exception err)
            {
                richTextBox1.Text += " \n " + err.ToString();
            }
        }

        private void button1_Click(object sender, EventArgs e)
        {
            try
            {
                richTextBox1.Text += " \n Csatlakozás a MySql-hez...";
                Conn.conn.Open();
                button1.Enabled = false;
                button3.Enabled = true;
            }
            catch (Exception err)
            {
                richTextBox1.Text += " \n " + err.ToString();
            }
        }

        private void button2_Click(object sender, EventArgs e)
        {
            try
            {
                string sql_create = File.ReadAllText("tablak.sql");
                MySqlCommand cmd_create = new MySqlCommand(sql_create, Conn.conn);
                cmd_create.ExecuteNonQuery();
                richTextBox1.Text += " \n A táblák létrejöttek";
                Thread.Sleep(100);
                //SQL INSERT
                string sql_insert = File.ReadAllText("adatok.sql");


                MySqlCommand cmd_insert = new MySqlCommand(sql_insert, Conn.conn);
                cmd_insert.ExecuteNonQuery();
                richTextBox1.Text += " \n Az adatok feltöltődtek";
            }
            catch (Exception err)
            {
                richTextBox1.Text += " \n " + err.ToString();
            }
            button2.Enabled = false;

        }

        private void button5_Click(object sender, EventArgs e)
        {
            try
            {
                //SQL SELECT
                string sql_select1 = "SELECT `fovaros` FROM `orszagok` WHERE `orszag` LIKE 'MADAGASZKÁR';";
                MySqlCommand cmd_select1 = new MySqlCommand(sql_select1, Conn.conn);
                MySqlDataReader rdr_select1 = cmd_select1.ExecuteReader();


                //megjelenítés
                while (rdr_select1.Read())
                {
                    richTextBox1.Text += " \n "+ "Mi MADAGASZKÁR fővárosa?: " + rdr_select1[0];
                }
                rdr_select1.Close();
            }
            catch (Exception err)
            {
                richTextBox1.Text += " \n " + err.ToString();
            }
        }

        private void button6_Click(object sender, EventArgs e)
        {
            try
            {
                //SQL SELECT
                string sql_select2 = "SELECT `orszag` FROM `orszagok` WHERE `fovaros` LIKE 'OUAGADOUGOU';";
                MySqlCommand cmd_select2 = new MySqlCommand(sql_select2, Conn.conn);
                MySqlDataReader rdr_select2 = cmd_select2.ExecuteReader();

                //megjelenítés
                while (rdr_select2.Read())
                {
                    richTextBox1.Text += " \n "+ "Melyik ország fővárosa OUAGADOUGOU?: " + rdr_select2[0];
                }

                rdr_select2.Close();
            }
            catch (Exception err)
            {
                richTextBox1.Text += " \n" + err.ToString();
            }
        }

        private void button7_Click(object sender, EventArgs e)
        {
            try
            {
                //SQL SELECT
                string sql_select2 = "SELECT `orszag` FROM `orszagok` WHERE `autojel` LIKE 'TT';";
                MySqlCommand cmd_select2 = new MySqlCommand(sql_select2, Conn.conn);
                MySqlDataReader rdr_select2 = cmd_select2.ExecuteReader();

                //megjelenítés
                while (rdr_select2.Read())
                {
                    richTextBox1.Text += " \n " + "Melyik ország autójele a TT?: " + rdr_select2[0];
                }

                rdr_select2.Close();
            }
            catch (Exception err)
            {
                richTextBox1.Text += " \n" + err.ToString();
            }
        }

        private void button8_Click(object sender, EventArgs e)
        {
            try
            {
                //SQL SELECT
                string sql_select4 = "SELECT szobak.id, szobak.szobaszam, SUM(foglalasok.napok) As szumma_nap FROM foglalasok INNER JOIN szobak ON foglalasok.szobaId = szobak.id GROUP BY szobak.szobaszam ORDER BY szumma_nap DESC LIMIT 5;";
                MySqlCommand cmd_select4 = new MySqlCommand(sql_select4, Conn.conn);
                MySqlDataReader rdr_select4 = cmd_select4.ExecuteReader();

                //megjelenítés
                while (rdr_select4.Read())
                {
                    richTextBox1.Text += " \n "+ "Legtöbb napra lefoglalt szobák: " + rdr_select4[0];
                }

                rdr_select4.Close();
            }
            catch (Exception err)
            {
                richTextBox1.Text += " \n " + err.ToString();
            }
        }

        private void button9_Click(object sender, EventArgs e)
        {
            try
            {
                //SQL SELECT
                string sql_select5 = "SELECT `orszag` FROM `orszagok` WHERE `penzjel` LIKE 'SGD';";
                MySqlCommand cmd_select5 = new MySqlCommand(sql_select5, Conn.conn);
                MySqlDataReader rdr_select5 = cmd_select5.ExecuteReader();

                //megjelenítés
                while (rdr_select5.Read())
                {
                    richTextBox1.Text += " \n "+ "Melyik ország pénzének jele az SGD?: " + rdr_select5[0];
                }

                rdr_select5.Close();
            }
            catch (Exception err)
            {
                richTextBox1.Text += " \n " + err.ToString();
            }
        }

        private void button4_Click(object sender, EventArgs e)
        {
            try
            {
                Conn.conn.Close();
                richTextBox1.Text += " \n DB kapcsolat bontva";
                richTextBox1.Text += " \n Kilépés...";
                Application.Exit();
            }
            catch (Exception err)
            {
                richTextBox1.Text += " \n " + err.ToString();
            }
        }

        private void button10_Click(object sender, EventArgs e)
        {
            try
            {
                //SQL SELECT
                string sql_select5 = "SELECT `orszag` FROM `orszagok` WHERE `telefon` = 61;";
                MySqlCommand cmd_select5 = new MySqlCommand(sql_select5, Conn.conn);
                MySqlDataReader rdr_select5 = cmd_select5.ExecuteReader();

                //megjelenítés
                while (rdr_select5.Read())
                {
                    richTextBox1.Text += " \n " + "Melyik ország nemzetközi telefon-hívószáma a 61?: " + rdr_select5[0];
                }

                rdr_select5.Close();
            }
            catch (Exception err)
            {
                richTextBox1.Text += " \n " + err.ToString();
            }
        }

        private void button11_Click(object sender, EventArgs e)
        {
            try
            {
                //SQL SELECT
                string sql_select5 = "SELECT `terulet` FROM `orszagok` WHERE `orszag` LIKE 'MONACO';";
                MySqlCommand cmd_select5 = new MySqlCommand(sql_select5, Conn.conn);
                MySqlDataReader rdr_select5 = cmd_select5.ExecuteReader();

                //megjelenítés
                while (rdr_select5.Read())
                {
                    richTextBox1.Text += " \n " + "Mekkora területű Monaco?: " + rdr_select5[0];
                }

                rdr_select5.Close();
            }
            catch (Exception err)
            {
                richTextBox1.Text += " \n " + err.ToString();
            }
        }

        private void button12_Click(object sender, EventArgs e)
        {
            try
            {
                //SQL SELECT
                string sql_select5 = "SELECT `nepesseg` FROM `orszagok` WHERE `orszag` LIKE 'MALTA';";
                MySqlCommand cmd_select5 = new MySqlCommand(sql_select5, Conn.conn);
                MySqlDataReader rdr_select5 = cmd_select5.ExecuteReader();

                //megjelenítés
                while (rdr_select5.Read())
                {
                    richTextBox1.Text += " \n " + "Hányan laknak Máltán?: " + rdr_select5[0];
                }

                rdr_select5.Close();
            }
            catch (Exception err)
            {
                richTextBox1.Text += " \n " + err.ToString();
            }
        }

        private void button13_Click(object sender, EventArgs e)
        {
            try
            {
                //SQL SELECT
                string sql_select5 = "SELECT `terulet`/`nepesseg` AS 'nepsuruseg' FROM `orszagok` WHERE `orszag` LIKE 'JAPAN';";
                MySqlCommand cmd_select5 = new MySqlCommand(sql_select5, Conn.conn);
                MySqlDataReader rdr_select5 = cmd_select5.ExecuteReader();

                //megjelenítés
                while (rdr_select5.Read())
                {
                    richTextBox1.Text += " \n " + "Mennyi Japán népsűrűsége?: " + rdr_select5[0];
                }

                rdr_select5.Close();
            }
            catch (Exception err)
            {
                richTextBox1.Text += " \n " + err.ToString();
            }
        }

        private void button14_Click(object sender, EventArgs e)
        {
            try
            {
                //SQL SELECT
                string sql_select5 = "SELECT SUM(`nepesseg`) AS 'fold_nepessege' FROM `orszagok`;";
                MySqlCommand cmd_select5 = new MySqlCommand(sql_select5, Conn.conn);
                MySqlDataReader rdr_select5 = cmd_select5.ExecuteReader();

                //megjelenítés
                while (rdr_select5.Read())
                {
                    richTextBox1.Text += " \n " + "Hány lakosa van a Földnek?: " + rdr_select5[0];
                }

                rdr_select5.Close();
            }
            catch (Exception err)
            {
                richTextBox1.Text += " \n " + err.ToString();
            }
        }

        private void button15_Click(object sender, EventArgs e)
        {
            try
            {
                //SQL SELECT
                string sql_select5 = "SELECT SUM(`terulet`) AS 'orszagok_terulete' FROM `orszagok`;";
                MySqlCommand cmd_select5 = new MySqlCommand(sql_select5, Conn.conn);
                MySqlDataReader rdr_select5 = cmd_select5.ExecuteReader();

                //megjelenítés
                while (rdr_select5.Read())
                {
                    richTextBox1.Text += " \n " + "Mennyi az országok területe összesen?: " + rdr_select5[0];
                }

                rdr_select5.Close();
            }
            catch (Exception err)
            {
                richTextBox1.Text += " \n " + err.ToString();
            }
        }

        private void button16_Click(object sender, EventArgs e)
        {
            try
            {
                //SQL SELECT
                string sql_select5 = "SELECT AVG(`nepesseg`) AS 'atlagnepesseg' FROM `orszagok`;";
                MySqlCommand cmd_select5 = new MySqlCommand(sql_select5, Conn.conn);
                MySqlDataReader rdr_select5 = cmd_select5.ExecuteReader();

                //megjelenítés
                while (rdr_select5.Read())
                {
                    richTextBox1.Text += " \n " + "Mennyi az országok átlagos népessége?: " + rdr_select5[0];
                }

                rdr_select5.Close();
            }
            catch (Exception err)
            {
                richTextBox1.Text += " \n " + err.ToString();
            }
        }

        private void button17_Click(object sender, EventArgs e)
        {
            try
            {
                //SQL SELECT
                string sql_select5 = "SELECT AVG(`terulet`) AS 'atlagterulet' FROM `orszagok`;";
                MySqlCommand cmd_select5 = new MySqlCommand(sql_select5, Conn.conn);
                MySqlDataReader rdr_select5 = cmd_select5.ExecuteReader();

                //megjelenítés
                while (rdr_select5.Read())
                {
                    richTextBox1.Text += " \n " + "Mennyi az országok átlagos területe?: " + rdr_select5[0];
                }

                rdr_select5.Close();
            }
            catch (Exception err)
            {
                richTextBox1.Text += " \n " + err.ToString();
            }
        }

        private void button18_Click(object sender, EventArgs e)
        {
            try
            {
                //SQL SELECT
                string sql_select5 = "SELECT SUM(`terulet`) / SUM(`nepesseg`) AS 'nepsuruseg' FROM `orszagok`;";
                MySqlCommand cmd_select5 = new MySqlCommand(sql_select5, Conn.conn);
                MySqlDataReader rdr_select5 = cmd_select5.ExecuteReader();

                //megjelenítés
                while (rdr_select5.Read())
                {
                    richTextBox1.Text += " \n " + "Mennyi a Föld népsűrűsége?: " + rdr_select5[0];
                }

                rdr_select5.Close();
            }
            catch (Exception err)
            {
                richTextBox1.Text += " \n " + err.ToString();
            }
        }

        private void button19_Click(object sender, EventArgs e)
        {
            try
            {
                //SQL SELECT
                string sql_select5 = "SELECT COUNT(`orszag`) FROM `orszagok` WHERE `terulet` > 1000000;";
                MySqlCommand cmd_select5 = new MySqlCommand(sql_select5, Conn.conn);
                MySqlDataReader rdr_select5 = cmd_select5.ExecuteReader();

                //megjelenítés
                while (rdr_select5.Read())
                {
                    richTextBox1.Text += " \n " + "Hány 1.000.000 km2-nél nagyobb területű ország van?: " + rdr_select5[0];
                }

                rdr_select5.Close();
            }
            catch (Exception err)
            {
                richTextBox1.Text += " \n " + err.ToString();
            }
        }

        private void button20_Click(object sender, EventArgs e)
        {
            try
            {
                //SQL SELECT
                string sql_select5 = "SELECT COUNT(`orszag`) FROM `orszagok` WHERE `terulet` < 100;";
                MySqlCommand cmd_select5 = new MySqlCommand(sql_select5, Conn.conn);
                MySqlDataReader rdr_select5 = cmd_select5.ExecuteReader();

                //megjelenítés
                while (rdr_select5.Read())
                {
                    richTextBox1.Text += " \n " + "Hány 100 km2-nél kisebb területű ország van?: " + rdr_select5[0];
                }

                rdr_select5.Close();
            }
            catch (Exception err)
            {
                richTextBox1.Text += " \n " + err.ToString();
            }
        }

        private void button21_Click(object sender, EventArgs e)
        {
            try
            {
                //SQL SELECT
                string sql_select5 = "SELECT COUNT(`orszag`) FROM `orszagok` WHERE `nepesseg` < 20000;";
                MySqlCommand cmd_select5 = new MySqlCommand(sql_select5, Conn.conn);
                MySqlDataReader rdr_select5 = cmd_select5.ExecuteReader();

                //megjelenítés
                while (rdr_select5.Read())
                {
                    richTextBox1.Text += " \n " + "Hány 20.000 főnél kevesebb lakosú ország van?: " + rdr_select5[0];
                }

                rdr_select5.Close();
            }
            catch (Exception err)
            {
                richTextBox1.Text += " \n " + err.ToString();
            }
        }

        private void button22_Click(object sender, EventArgs e)
        {
            try
            {
                //SQL SELECT
                string sql_select5 = "SELECT COUNT(`orszag`) FROM `orszagok` WHERE `nepesseg` < 20000 OR `terulet` < 100;";
                MySqlCommand cmd_select5 = new MySqlCommand(sql_select5, Conn.conn);
                MySqlDataReader rdr_select5 = cmd_select5.ExecuteReader();

                //megjelenítés
                while (rdr_select5.Read())
                {
                    richTextBox1.Text += " \n " + "Hány országra igaz, hogy területe kisebb 100 km2-nél, vagy pedig a lakossága kevesebb 20.000 főnél?: " + rdr_select5[0];
                }

                rdr_select5.Close();
            }
            catch (Exception err)
            {
                richTextBox1.Text += " \n " + err.ToString();
            }
        }

        private void button23_Click(object sender, EventArgs e)
        {
            try
            {
                //SQL SELECT
                string sql_select5 = "SELECT COUNT(`orszag`) FROM `orszagok` WHERE `terulet` BETWEEN 50 AND 150;";
                MySqlCommand cmd_select5 = new MySqlCommand(sql_select5, Conn.conn);
                MySqlDataReader rdr_select5 = cmd_select5.ExecuteReader();

                //megjelenítés
                while (rdr_select5.Read())
                {
                    richTextBox1.Text += " \n " + "Hány ország területe 50.000 és 150.000 km2 közötti?: " + rdr_select5[0];
                }

                rdr_select5.Close();
            }
            catch (Exception err)
            {
                richTextBox1.Text += " \n " + err.ToString();
            }
        }

        private void button24_Click(object sender, EventArgs e)
        {
            try
            {
                //SQL SELECT
                string sql_select5 = "SELECT COUNT(`orszag`) FROM `orszagok` WHERE `nepesseg` BETWEEN 8000 AND 12000;";
                MySqlCommand cmd_select5 = new MySqlCommand(sql_select5, Conn.conn);
                MySqlDataReader rdr_select5 = cmd_select5.ExecuteReader();

                //megjelenítés
                while (rdr_select5.Read())
                {
                    richTextBox1.Text += " \n " + "Hány ország lakossága 8 és 12 millió közötti?: " + rdr_select5[0];
                }

                rdr_select5.Close();
            }
            catch (Exception err)
            {
                richTextBox1.Text += " \n " + err.ToString();
            }
        }
    }
}

    

